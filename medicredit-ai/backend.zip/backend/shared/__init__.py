# Shared utilities for MediCredit AI backend

